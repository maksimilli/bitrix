from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from scipy import signal

ROOT=Path(__file__).parent
FS=80; WINDOW=60
PPG=['PR','PPI_SD','PPI_RMSSD','prominence_median','prominence_CV','PPG_SD','PPG_entropy']
FLOW=['flow_RMS','flow_SD','flow_P90_P10','flow_derivative_SD','flow_entropy']
SOS=signal.butter(3,[.5,8],fs=80,btype='bandpass',output='sos')
FLOW_SOS=signal.butter(3,[.05,2],fs=20,btype='bandpass',output='sos')
APNEA=['APNEA-OBSTRUCTIVE','APNEA-CENTRAL','APNEA-MIXED']

def longest(mask):
    e=np.diff(np.r_[False,mask,False].astype(int));a=np.flatnonzero(e==1);b=np.flatnonzero(e==-1)
    return int(max(b-a,default=0))

def entropy(x,fs,lo,hi):
    f,p=signal.welch(x,fs=fs,nperseg=min(1024,len(x)));p=p[(f>=lo)&(f<=hi)]
    if p.sum()<=0:return 0.
    p=p/p.sum();return float(-sum(p*np.log(p+1e-15))/np.log(len(p)))

def features(x,f):
    quality=dict(ppg_missing=float(np.mean(~np.isfinite(x))),flow_missing=float(np.mean(~np.isfinite(f))),
        ppg_constant_run_s=longest(np.r_[False,np.diff(x)==0])/80)
    if not np.isfinite(x).all() or not np.isfinite(f).all():return {},quality,'missing'
    if quality['ppg_constant_run_s']>=2:return {},quality,'PPG constant run >=2s'
    y=signal.sosfiltfilt(SOS,x)
    if np.std(y)<1e-10:return {},quality,'flat PPG'
    peaks,props=signal.find_peaks(y,distance=28,prominence=.3*np.std(y))
    ppi=np.diff(peaks)/80;ok=(ppi>=.35)&(ppi<=2.)
    quality['invalid_PPI_fraction']=float(1-ok.mean()) if len(ok) else 1.
    if ok.sum()<15 or quality['invalid_PPI_fraction']>.2:return {},quality,'unreliable peaks'
    d=np.diff(ppi)[ok[:-1]&ok[1:]]
    if len(d)<2:return {},quality,'few intervals'
    amp=props['prominences'];good=ppi[ok]
    values=[60/np.median(good),np.std(good),np.sqrt(np.mean(d*d)),np.median(amp),np.std(amp)/np.mean(amp),np.std(y),entropy(y,80,.5,8)]
    ff=signal.sosfiltfilt(FLOW_SOS,f)
    fv=[np.sqrt(np.mean(ff**2)),np.std(ff),np.quantile(ff,.9)-np.quantile(ff,.1),np.std(np.diff(ff)*20),entropy(ff,20,.05,2)]
    return dict(zip(PPG+FLOW,map(float,values+fv))),quality,'accepted'
