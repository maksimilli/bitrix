from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.special import logit
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score,average_precision_score,brier_score_loss,precision_recall_curve

ROOT=Path(__file__).parent
def pipeline(c):return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(C=c,class_weight='balanced',max_iter=2000,random_state=42))
def score(y,p,pred):
    y=np.asarray(y);pred=np.asarray(pred);tp=np.sum((y==1)&(pred==1));tn=np.sum((y==0)&(pred==0));fp=np.sum((y==0)&(pred==1));fn=np.sum((y==1)&(pred==0))
    div=lambda a,b:float(a/b) if b else np.nan
    return dict(ROC_AUC=roc_auc_score(y,p) if len(np.unique(y))==2 else np.nan,PR_AUC=average_precision_score(y,p) if np.sum(y)>0 else np.nan,
        Brier=brier_score_loss(y,p),accuracy=div(tp+tn,len(y)),sensitivity=div(tp,tp+fn),specificity=div(tn,tn+fp),
        precision=div(tp,tp+fp),F1=div(2*tp,2*tp+fp+fn),balanced_accuracy=(div(tp,tp+fn)+div(tn,tn+fp))/2)

def evaluate(frame,ppg,flow,out=ROOT,boots=500):
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    f=frame[frame.y.notna()].reset_index(drop=True);f['y']=f.y.astype(int)
    y=f.y.to_numpy();groups=f.patient.astype(str).to_numpy();cv=GroupKFold(5)
    predictions=[];folds=[];coefficients=[]
    models={'PPG':ppg,'flow_only':flow,'PPG_plus_flow':ppg+flow}
    for model,cols in models.items():
        for fold,(train,test) in enumerate(cv.split(f,y,groups),1):
            assert not set(groups[train])&set(groups[test])
            x=f[cols];yt=y[train];gt=groups[train];splits=list(GroupKFold(3).split(train,yt,gt))
            candidates=[]
            for c in [.1,1.,10.]:
                inner_p=np.full(len(train),np.nan)
                for it,iv in splits:
                    assert not set(gt[it])&set(gt[iv])
                    m=pipeline(c);m.fit(x.iloc[train[it]],yt[it]);inner_p[iv]=m.predict_proba(x.iloc[train[iv]])[:,1]
                candidates.append((average_precision_score(yt,inner_p),c,inner_p))
            _,chosen_c,inner_p=max(candidates,key=lambda z:z[0])
            calibration=LogisticRegression(C=1e6,max_iter=1000)
            calibration.fit(logit(np.clip(inner_p,1e-6,1-1e-6)).reshape(-1,1),yt)
            calibrated_inner=calibration.predict_proba(logit(np.clip(inner_p,1e-6,1-1e-6)).reshape(-1,1))[:,1]
            precision,recall,thresholds=precision_recall_curve(yt,calibrated_inner)
            f1=2*precision[:-1]*recall[:-1]/np.maximum(precision[:-1]+recall[:-1],1e-15)
            threshold=float(thresholds[np.flatnonzero(f1==np.max(f1))[-1]])
            m=pipeline(chosen_c);m.fit(x.iloc[train],yt)
            base=m.predict_proba(x.iloc[test])[:,1]
            p=calibration.predict_proba(logit(np.clip(base,1e-6,1-1e-6)).reshape(-1,1))[:,1]
            block=f.iloc[test][['patient','source_row','timestamp','y']].copy();block['model']=model;block['fold']=fold
            block['probability']=p;block['threshold']=threshold;block['prediction']=(p>=threshold).astype(int);predictions.append(block)
            folds.append(dict(model=model,fold=fold,C=chosen_c,threshold=threshold,
                train_patients=','.join(sorted(set(groups[train]))),test_patients=','.join(sorted(set(groups[test]))),
                calibration_slope=float(calibration.coef_[0,0]),calibration_intercept=float(calibration.intercept_[0])))
            for feature,weight in zip(cols,m[-1].coef_[0]):coefficients.append(dict(model=model,fold=fold,feature=feature,standardized_weight=float(weight),calibrated_weight=float(weight*calibration.coef_[0,0]),intercept=float(m[-1].intercept_[0])))
            print(model,'fold',fold,'done',flush=True)
    oof=pd.concat(predictions,ignore_index=True);oof.to_csv(out/'oof_predictions.csv',index=False)
    pd.DataFrame(folds).to_csv(out/'fold_parameters.csv',index=False);pd.DataFrame(coefficients).to_csv(out/'coefficients.csv',index=False)
    metrics=[];intervals=[];rng=np.random.default_rng(42)
    for name,g in oof.groupby('model'):
        point=score(g.y,g.probability,g.prediction);metrics.append(dict(model=name,windows=len(g),patients=g.patient.nunique(),prevalence=g.y.mean(),**point))
        clustered={pid:v for pid,v in g.groupby('patient')};ids=list(clustered)
        draws=[]
        for _ in range(boots):
            sampled=pd.concat([clustered[ids[i]] for i in rng.integers(0,len(ids),len(ids))],ignore_index=True)
            draws.append(score(sampled.y,sampled.probability,sampled.prediction))
        for metric,value in point.items():
            values=np.array([d[metric] for d in draws]);valid=values[np.isfinite(values)]
            intervals.append(dict(model=name,metric=metric,estimate=value,lower=float(np.quantile(valid,.025)) if len(valid) else np.nan,upper=float(np.quantile(valid,.975)) if len(valid) else np.nan,valid_bootstraps=len(valid)))
    pd.DataFrame(metrics).to_csv(out/'metrics.csv',index=False);pd.DataFrame(intervals).to_csv(out/'cluster_bootstrap_CI.csv',index=False)
    return oof,pd.DataFrame(metrics),pd.DataFrame(intervals)

if __name__=='__main__':
    manifest=json.loads((ROOT/'manifest.json').read_text());f=pd.read_csv(ROOT/'features_all.csv',dtype={'patient':str})
    evaluate(f,manifest['PPG_features'],manifest['flow_features'])
