"""Пересчёт признаков только из небольших обрезанных NPZ. Pickle не нужен."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from signal_features import features,APNEA

def rebuild(root):
    root=Path(root);manifest=json.loads((root/'manifest.json').read_text());rows=[];qc=[]
    for pid in sorted(manifest['examples'],key=int):
        p=root/f'patient_{pid}.npz'
        assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest['examples'][pid]['sha256'],pid
        with np.load(p,allow_pickle=False) as z:d={k:z[k].copy() for k in z.files}
        assert d['signal_pleth'].shape==(1800,80) and d['PSG_Flow'].shape==(1800,20)
        for start in range(0,1800,60):
            ev=d['event'][start:start+60];n=int(np.isin(ev,APNEA).sum())
            label=1 if n>=10 else (0 if np.all(ev=='NONE') else None)
            if np.any(ev=='HYPOPNEA') or not np.isin(ev,APNEA+['NONE']).all():label=None
            feat,q,reason=features(d['signal_pleth'][start:start+60].astype(float).reshape(-1),d['PSG_Flow'][start:start+60].astype(float).reshape(-1))
            base=dict(patient=pid,segment=1,source_row=int(d['source_row'][start]),timestamp=d['timestamp_datetime'][start],apnea_seconds=n,label_eligible=label is not None,quality=reason,**q)
            qc.append(base)
            if reason=='accepted':
                h=d['monitor_HR'][start:start+60];h=h[np.isfinite(h)&(h>0)]
                rows.append(dict(**base,y=np.nan if label is None else label,monitor_HR_median=float(np.median(h)) if len(h) else np.nan,**feat))
    f=pd.DataFrame(rows);q=pd.DataFrame(qc);f.to_csv(root/'features_all.csv',index=False);q.to_csv(root/'quality_all.csv',index=False)
    return f,q
if __name__=='__main__':rebuild(Path(__file__).parent)
