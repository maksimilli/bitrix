from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve,precision_recall_curve
from sklearn.calibration import calibration_curve
from signal_features import SOS
from scipy import signal

def spans(labels):
    edges=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1,len(labels)]
    return [(a,b,str(labels[a])) for a,b in zip(edges[:-1],edges[1:])]

def plots(root):
    root=Path(root);out=root/'figures';out.mkdir(exist_ok=True)
    oof=pd.read_csv(root/'oof_predictions.csv',dtype={'patient':str})
    features=pd.read_csv(root/'features_all.csv',dtype={'patient':str});q=pd.read_csv(root/'quality_all.csv',dtype={'patient':str})
    coverage=q.groupby(['patient','quality','label_eligible']).size().rename('windows').reset_index();coverage.to_csv(root/'coverage_by_patient.csv',index=False)
    valid=features[np.isfinite(features.monitor_HR_median)&(features.monitor_HR_median>0)].copy()
    error=valid.PR-valid.monitor_HR_median
    hr=dict(windows=len(valid),patients=valid.patient.nunique(),MAE=float(np.mean(abs(error))),RMSE=float(np.sqrt(np.mean(error**2))),bias=float(error.mean()),
        limits_of_agreement=[float(error.mean()-1.96*error.std()),float(error.mean()+1.96*error.std())],
        caveat='Rate agreement only, not validation of individual peak positions; ECG heart rate and peripheral pulse can differ.')
    (root/'pulse_validation.json').write_text(json.dumps(hr,indent=2),encoding='utf-8')
    fig,ax=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    ax[0].scatter(valid.monitor_HR_median,valid.PR,s=3,alpha=.2);lo=min(valid.monitor_HR_median.min(),valid.PR.min());hi=max(valid.monitor_HR_median.max(),valid.PR.max());ax[0].plot([lo,hi],[lo,hi],'k--')
    ax[0].set(xlabel='HR(bpm): медиана за 60 с, ЭКГ',ylabel='PR из signal_pleth, уд/мин',title='Согласие оценок частоты; все принятые окна')
    ax[1].scatter((valid.PR+valid.monitor_HR_median)/2,error,s=3,alpha=.2)
    for line in [hr['bias']]+hr['limits_of_agreement']:ax[1].axhline(line,ls='--',color='black')
    ax[1].set(xlabel='Среднее двух оценок, уд/мин',ylabel='PR − HR(bpm), уд/мин',title='Bland–Altman: не ручная проверка пиков')
    fig.savefig(out/'pulse_validation.png',dpi=150);plt.close(fig)
    fig,ax=plt.subplots(1,3,figsize=(13,4),layout='constrained')
    for name,g in oof.groupby('model'):
        fpr,tpr,_=roc_curve(g.y,g.probability);precision,recall,_=precision_recall_curve(g.y,g.probability)
        true,pred=calibration_curve(g.y,g.probability,n_bins=10,strategy='quantile')
        ax[0].plot(fpr,tpr,label=name);ax[1].plot(recall,precision,label=name);ax[2].plot(pred,true,'o-',label=name)
    ax[0].plot([0,1],[0,1],'k--');ax[2].plot([0,1],[0,1],'k--')
    ax[1].axhline(oof[oof.model=='PPG'].y.mean(),color='black',ls='--')
    ax[0].set(xlabel='False positive rate',ylabel='Sensitivity',title='Внешние OOF: ROC')
    ax[1].set(xlabel='Recall',ylabel='Precision',title='Внешние OOF: PR (AUC = AP)')
    ax[2].set(xlabel='Средняя вероятность',ylabel='Доля положительных окон',title='Внешняя калибровка, Brier в таблице')
    handles,labels=ax[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=3)
    fig.savefig(out/'ROC_PR_calibration.png',dpi=160);plt.close(fig)
    for pid in json.loads((root/'manifest.json').read_text()).get('illustration_patients',['3','5','6']):
        with np.load(root/f'patient_{pid}.npz',allow_pickle=False) as z:d={k:z[k].copy() for k in z.files}
        n=len(d['event']);duration=n/60
        fig,ax=plt.subplots(5,1,figsize=(13,10),sharex=True,layout='constrained')
        for target,column,fs in [(ax[0],'signal_pleth',80),(ax[1],'PSG_Flow',20)]:
            v=d[column].reshape(-1);target.plot(np.arange(len(v))/fs/60,v,lw=.45)
            for a,b,label in spans(d['event']):
                if label.startswith('APNEA'):target.axvspan(a/60,b/60,color='royalblue',alpha=.17)
                elif label=='HYPOPNEA':target.axvspan(a/60,b/60,color='gold',alpha=.17)
            target.set(ylabel=column+'\nусл. ед.',title=f'patient {pid}: исходный {column}; синий — event APNEA, жёлтый — HYPOPNEA')
        for target,name in zip(ax[2:],['PPG','flow_only','PPG_plus_flow']):
            g=oof[(oof.patient==pid)&(oof.model==name)].set_index('source_row')
            for s in range(0,n,60):
                row=int(d['source_row'][s])
                if row in g.index:
                    a=g.loc[row];target.plot([s/60,(s+60)/60],[a.probability]*2,color='purple')
                    target.plot([s/60,(s+60)/60],[a.threshold]*2,'k--',lw=.7)
                    if a.prediction:target.axvspan(s/60,(s+60)/60,color='tomato',alpha=.15)
                else:target.axvspan(s/60,(s+60)/60,color='gray',alpha=.12)
            target.set(ylabel='Вероятность',ylim=(0,1),title=f'{name}: вероятность OOF; пунктир — внутренний CV-порог; красный — положительное окно; серый — нет оценки')
        ax[-1].set(xlabel='От начала выбранного фрагмента, минуты',xlim=(0,duration))
        fig.savefig(out/f'patient_{pid}_30min.png',dpi=150);plt.close(fig)
        x=d['signal_pleth'][300:330].reshape(-1)
        if np.isfinite(x).all():
            y=signal.sosfiltfilt(SOS,x);peaks,_=signal.find_peaks(y,distance=28,prominence=.3*np.std(y))
            fig,ax=plt.subplots(figsize=(12,3),layout='constrained');t=np.arange(len(x))/80
            ax.plot(t,y);ax.plot(peaks/80,y[peaks],'ro',ms=3)
            ax.set(xlabel='От начала 30-секундного увеличения, секунды',ylabel='signal_pleth, после фильтра, усл. ед.',title=f'patient {pid}: проверка пиков на фиксированных 30 с (не отобрано по успеху модели)')
            fig.savefig(out/f'patient_{pid}_peaks.png',dpi=150);plt.close(fig)
    from evaluate import score
    patient=[]
    for (name,pid),g in oof.groupby(['model','patient']):patient.append(dict(model=name,patient=pid,**score(g.y,g.probability,g.prediction)))
    pd.DataFrame(patient).to_csv(root/'metrics_by_patient.csv',index=False)
    pd.DataFrame(patient).groupby('model').mean(numeric_only=True).to_csv(root/'macro_patient_metrics.csv')
    pd.DataFrame([dict(model=name,fold=fold,**score(g.y,g.probability,g.prediction))
        for (name,fold),g in oof.groupby(['model','fold'])]).to_csv(root/'metrics_by_fold.csv',index=False)
if __name__=='__main__':plots(Path(__file__).parent)
