OSASUD: 30 patients x 30 minutes = 15 hours. Original values and event labels; no synthetic samples.
Each patient_N.npz contains signal_pleth (1800,80), PSG_Flow (1800,20), event, timestamp_datetime, monitor_HR, source_row, patient.
monitor_HR originates from source HR(bpm), ECG; never used as classifier input.
No full dataset_OSAS.pickle required. Selection uses QC, not event; see manifest.json.
